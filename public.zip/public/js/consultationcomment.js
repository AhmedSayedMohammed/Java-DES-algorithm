
$(document).ready(function () {


                $.ajaxSetup({

                    headers: {

                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                    }
                });

            $('#frm-consultation_comment').on('submit', function (e) {
                e.preventDefault();
                var data = $(this).serialize();
                var url = $(this).attr('action');
                var post = $(this).attr('method');
                $.ajax({
                    type: post,
                    url: url,
                    data: data,
                    dataTy: 'json',
                    success: function (data) {
                        console.log(data.html);
                        $("#consultation_comment_section").append(data.html);
                        $('#consultation_comment').html('');
                    }
            
    
            });

            });
            $('input:text').focus(function(){
                $(this).val('');
           });
                


});  
    