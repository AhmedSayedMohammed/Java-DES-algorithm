                  
                    $(document).ready(function () {


                        $.ajaxSetup({

                            headers: {

                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                            }
                        });
                  var page = 1;
                    $(window).scroll(function () {
                        if ($(window).scrollTop() + $(window).height() >= $(document).height()) {
                            page++;
                            loadMoreData(page);
                        }
                    });

                     
                    function loadMoreData(page) {
                        $.ajax({
                                url: '?page=' + page,
                                type: "get",
                                beforeSend: function () {
                                    $('.ajax-load').show();
                                }
                            })
                            .done(function (data) {
                                if (data.html == "") {
                                    $('.ajax-load').html("No more posts");
                                    return;
                                } else {
                                    $('.ajax-load').hide();
                                    $("#post-data").append(data.html);
                                    console.log(data.html);
                                }
                            })
                            .fail(function (jqXHR, ajaxOptions, thrownError) {
                                alert(thrownError);
                            });
                    }


                    //post method for posts





                        $.ajaxSetup({

                            headers: {

                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

                            }

                        });

                        $('#frm-insert').on('submit', function (e) {
                            e.preventDefault();
                            var data = $(this).serialize();
                            var url  = $(this).attr('action');
                            var post = $(this).attr('method');

                            $.ajax({
                                type: post,
                                url: url,
                                data: data,
                                dataTy: 'json',
                                success: function (data) {
                                    console.log(data.html);
                                    $("#post-data").append(data.html);
                                }
                            })

                        });

                        
                        $('#frm-comment').on('submit', function (e) {
                            e.preventDefault();
                            var data = $(this).serialize();
                            var url = $(this).attr('action');
                            var post = $(this).attr('method');
                            $.ajax({
                                type: post,
                                url: url,
                                data: data,
                                dataTy: 'json',
                                success: function (data) {
                                    console.log(data.html);
                                    $("#comment-data").html(data.html);
                                }
                           

                        });
                     
                    });

                    $('#frm-like').on('submit', function (e) {
                        e.preventDefault();
                        var data = $(this).serialize();
                        var url = $(this).attr('action');
                        var post = $(this).attr('method');
                        $.ajax({
                            type: post,
                            url: url,
                            data: data,
                            dataTy: 'json',
                            success: function (data) {
                                     console.log(data.html);
                        $('#like').html('<input type="submit" value="liked" class="btn btn-dark button-small" style="width: 100%;" id="frm-removelike">');

                            }
                       
                    })

                 
                });

                
                        
                $('#frm-consultation_comment').on('submit', function (e) {
                    e.preventDefault();
                    var data = $(this).serialize();
                    var url = $(this).attr('action');
                    var post = $(this).attr('method');
                    $.ajax({
                        type: post,
                        url: url,
                        data: data,
                        dataTy: 'json',
                        success: function (data) {
                            console.log(data.html);
                            $("#consultation_comment_section").append(data.html);
                       
                        }
                   

                });
             
            });
            $('input:text').focus(function(){
                $(this).val('');
           });

    });  
                    