           $(document).ready(function () {
             $('.like').on('click',function(e){
                e.preventDefault();
                     var islike=e.target.previousElementSibling==null;
                     var postid=e.target.parentNode.dataset['postid'];
                    console.log(postid);
                   
                     $.ajax({
                        type: 'post',
                        url: likeurl,
                        data: {like:islike , post_id: postid,_token:token},
                        success: function (data) {
                            $("#like-data").html(data.html);
                            console.log(data.html);
                        }
                    })
               });
            });